"""src/app.py
Flask API para exponer el modelo y preprocesamiento.
"""
from flask import Flask, request, jsonify, render_template_string
import os, json
from src.preprocessing import clean_text

app = Flask(__name__)

TEMPLATE = '''
<html><body>
<h2>Fake News Classifier - Perú (Demo)</h2>
<form method="post" action="/predict">
  <textarea name="text" rows="8" cols="80"></textarea><br/>
  <button type="submit">Predecir</button>
</form>
{% if result is defined %}
  <h3>Resultado: {{result}}</h3>
{% endif %}
</body></html>
'''

@app.route('/', methods=['GET'])
def index():
    return render_template_string(TEMPLATE)

@app.route('/predict', methods=['POST'])
def predict():
    text = request.form.get('text','')
    if not text:
        return jsonify({'error':'No text provided'}), 400
    text_clean = clean_text(text)
    # Aquí se invocaría el modelo; por ahora devolvemos texto limpio
    return render_template_string(TEMPLATE, result=f'Texto limpio:\n\n{text_clean}')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
