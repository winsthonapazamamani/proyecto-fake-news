"""src/train_lstm.py
Script base para entrenar un clasificador LSTM con Keras.
NOTA: Este es un esqueleto; ajuste hiperparámetros y embeddings según su dataset.
"""
import json, os
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout, Bidirectional
from tensorflow.keras.callbacks import ModelCheckpoint

def load_data(path='../data/sample_dataset_clean.json'):
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    texts = [d['text_clean'] for d in data]
    labels = [d['label'] for d in data]
    return texts, np.array(labels)

def build_model(vocab_size=5000, maxlen=200):
    model = Sequential()
    model.add(Embedding(input_dim=vocab_size, output_dim=128, input_length=maxlen))
    model.add(Bidirectional(LSTM(64)))
    model.add(Dropout(0.5))
    model.add(Dense(32, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

if __name__ == '__main__':
    texts, y = load_data()
    tokenizer = Tokenizer(num_words=5000, oov_token='<OOV>')
    tokenizer.fit_on_texts(texts)
    sequences = tokenizer.texts_to_sequences(texts)
    maxlen = 200
    X = pad_sequences(sequences, maxlen=maxlen, padding='post')
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = build_model(vocab_size=5000, maxlen=maxlen)
    os.makedirs('../models', exist_ok=True)
    chk = ModelCheckpoint('../models/best_model.h5', save_best_only=True, monitor='val_loss')
    model.fit(X_train, y_train, epochs=2, batch_size=32, validation_split=0.1, callbacks=[chk])
    loss, acc = model.evaluate(X_test, y_test)
    print('Test accuracy:', acc)
