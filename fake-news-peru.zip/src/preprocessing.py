"""src/preprocessing.py
Limpieza y preparación de texto en español.
"""
import re, string, json, os
import nltk
from nltk.corpus import stopwords
nltk.download('stopwords', quiet=True)

SPANISH_STOPWORDS = set(stopwords.words('spanish'))

def clean_text(text):
    text = text.lower()
    text = re.sub(r'http\S+', ' ', text)
    text = re.sub(r'@\w+', ' ', text)
    text = re.sub(r'#\w+', ' ', text)
    text = re.sub(r'[%s]' % re.escape(string.punctuation), ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    # remove stopwords
    tokens = [w for w in text.split() if w not in SPANISH_STOPWORDS]
    return ' '.join(tokens)

def preprocess_file(infile, outfile):
    os.makedirs(os.path.dirname(outfile), exist_ok=True)
    with open(infile, 'r', encoding='utf-8') as f:
        data = json.load(f)
    for r in data:
        r['text_clean'] = clean_text(r.get('text','') + ' ' + r.get('title',''))
    with open(outfile, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print('Preprocessed saved to', outfile)

if __name__ == '__main__':
    preprocess_file('../data/sample_dataset.json', '../data/sample_dataset_clean.json')
