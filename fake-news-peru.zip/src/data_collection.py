"""src/data_collection.py
Script base para recolección de noticias. Aquí se deben añadir scrapers o APIs de fact-checkers.
NOTA: Respete robots.txt y términos de servicio al recolectar datos.
"""
import os
import requests
import json
from datetime import datetime

def save_sample():
    os.makedirs('../data', exist_ok=True)
    sample = [
        {'id': '1', 'source':'El Comercio', 'title':'Ejemplo real', 'text':'Contenido veraz de ejemplo', 'label':0},
        {'id': '2', 'source':'WhatsApp', 'title':'Ejemplo falso', 'text':'Contenido falso de ejemplo', 'label':1}
    ]
    with open('../data/sample_dataset.json', 'w', encoding='utf-8') as f:
        json.dump(sample, f, ensure_ascii=False, indent=2)
    print('Sample dataset saved to data/sample_dataset.json')

if __name__ == '__main__':
    save_sample()
