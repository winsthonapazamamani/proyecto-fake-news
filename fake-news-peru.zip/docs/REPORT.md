# Informe del Proyecto - Clasificador de Fake News (Perú)

## RESUMEN

El proyecto desarrolla un clasificador automático de noticias falsas adaptado al contexto peruano,
empleando técnicas de Procesamiento de Lenguaje Natural y redes LSTM. La aplicación final será una
plataforma web que permita a periodistas y ciudadanos verificar la veracidad de textos en español.

## 1. Definición del problema (resumen)
- Organización: Ama Llulla (referencia para el dominio), sede en Lima, Perú.
- Problema: alta propagación de desinformación en redes sociales; proceso de verificación manual y lento.
- Misión: desarrollar herramienta automática que apoye la verificación.

## 2. Fundamentos teóricos (resumen)
- Procesamiento de Lenguaje Natural (Manning & Schütze, 1999)
- LSTM: redes recurrentes para dependencias a largo plazo (Hochreiter & Schmidhuber, 1997)
- Embeddings (Word2Vec, FastText)
- Frameworks: TensorFlow/Keras, Flask/Django

## 3. Cronograma (resumen)
Ver `docs/CRONOGRAMA.xlsx` para detalles en formato Excel.

## 4. Referencias (APA)
- Hochreiter, S., & Schmidhuber, J. (1997). Long Short-Term Memory. Neural Computation, 9(8), 1735–1780. https://doi.org/10.1162/neco.1997.9.8.1735
- Chollet, F. (2017). Deep Learning with Python. Manning Publications.
- Ama Llulla. (2022). Informe. https://www.undp.org/sites/g/files/zskgke326/files/2022-09/UNDP-PE-AmaLlulla-Informe-2021.pdf
