# Fake News Classifier - Perú
Proyecto para la detección automática de noticias falsas orientado al contexto peruano.
Repositorio plantilla con: código, documentación, cronograma, y scripts base para implementación con LSTM + Flask.

## Estructura
- `src/` - código fuente (recolección, preprocesamiento, entrenamiento, API)
- `models/` - modelos entrenados (no subir modelos grandes a GitHub)
- `data/` - datasets (incluir enlaces o muestras; evitar publicar datos sensibles)
- `docs/` - documentación del proyecto, cronograma y referencias
- `.github/workflows` - CI básico

## Cómo empezar (local)
1. Clonar el repositorio
2. Crear entorno virtual: `python -m venv venv && source venv/bin/activate`
3. Instalar dependencias: `pip install -r requirements.txt`
4. Preparar datos en `data/` y ejecutar scripts en `src/`

## Licencia
MIT License (ver LICENSE)
